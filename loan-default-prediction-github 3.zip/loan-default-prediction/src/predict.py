"""Predict loan-default risk for one customer using the saved model."""
from pathlib import Path
import argparse
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "best_model.joblib"

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--employed", type=int, choices=[0, 1], required=True,
                        help="1 if employed, otherwise 0")
    parser.add_argument("--bank-balance", type=float, required=True,
                        help="Customer's current bank balance")
    parser.add_argument("--annual-salary", type=float, required=True,
                        help="Customer's annual salary")
    args = parser.parse_args()

    artifact = joblib.load(MODEL_PATH)
    features = pd.DataFrame([{
        "Employed": args.employed,
        "Bank_Balance": args.bank_balance,
        "Annual_Salary": args.annual_salary,
    }], columns=artifact["features"])
    probability = float(artifact["model"].predict_proba(features)[0, 1])
    prediction = int(probability >= artifact.get("threshold", 0.5))
    label = "Higher predicted default risk" if prediction else "Lower predicted default risk"
    print(f"Model: {artifact['model_name']}")
    print(f"Predicted default probability: {probability:.1%}")
    print(f"Screening result: {label}")
    print("Note: This is a coursework model, not a real lending decision or financial advice.")

if __name__ == "__main__":
    main()
