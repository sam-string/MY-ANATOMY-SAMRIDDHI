"""
Loan Default Prediction System
Train and compare Logistic Regression, Random Forest, RBF SVM, and XGBoost.
Run from the repository root: python src/train.py
"""
from pathlib import Path
import json
import warnings

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, confusion_matrix, classification_report
)
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier

warnings.filterwarnings("ignore", category=FutureWarning)
ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "Default_Fin.csv"
OUT = ROOT / "outputs"
FIG = OUT / "figures"
MODEL_DIR = ROOT / "models"
for folder in (OUT, FIG, MODEL_DIR):
    folder.mkdir(parents=True, exist_ok=True)

RANDOM_STATE = 42
sns.set_theme(style="whitegrid")
plt.rcParams["figure.dpi"] = 130

def main():
    df = pd.read_csv(DATA_PATH)
    required = {"Index", "Employed", "Bank Balance", "Annual Salary", "Defaulted?"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")
    if df.empty:
        raise ValueError("The dataset is empty.")
    if df["Defaulted?"].nunique() != 2:
        raise ValueError("Target 'Defaulted?' must contain two classes (0 and 1).")

    # Drop the row identifier and standardize column names.
    df = df.drop(columns=["Index"]).rename(columns={
        "Bank Balance": "Bank_Balance",
        "Annual Salary": "Annual_Salary",
        "Defaulted?": "Defaulted",
    })
    if df.isna().any().any():
        raise ValueError("Missing values were found. Please clean the dataset first.")

    X = df.drop(columns="Defaulted")
    y = df["Defaulted"].astype(int)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE, stratify=y
    )
    pos_weight = (y_train == 0).sum() / max((y_train == 1).sum(), 1)

    # Pipelines ensure scaling is learned only from the training data.
    models = {
        "Logistic Regression": Pipeline([
            ("scaler", StandardScaler()),
            ("model", LogisticRegression(
                max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE
            )),
        ]),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, class_weight="balanced", random_state=RANDOM_STATE,
            n_jobs=-1
        ),
        "SVM (RBF)": Pipeline([
            ("scaler", StandardScaler()),
            ("model", SVC(
                kernel="rbf", probability=True, class_weight="balanced",
                random_state=RANDOM_STATE
            )),
        ]),
        "XGBoost": XGBClassifier(
            n_estimators=300, max_depth=4, learning_rate=0.05,
            scale_pos_weight=pos_weight, eval_metric="logloss",
            random_state=RANDOM_STATE, n_jobs=-1
        ),
    }

    metrics = []
    roc_curves = {}
    confusion_matrices = {}
    predictions = pd.DataFrame(index=y_test.index)
    predictions["Actual_Defaulted"] = y_test

    for name, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        prob = model.predict_proba(X_test)[:, 1]
        row = {
            "Model": name,
            "Accuracy": accuracy_score(y_test, pred),
            "Precision": precision_score(y_test, pred, zero_division=0),
            "Recall": recall_score(y_test, pred, zero_division=0),
            "F1-Score": f1_score(y_test, pred, zero_division=0),
            "ROC-AUC": roc_auc_score(y_test, prob),
        }
        metrics.append(row)
        fpr, tpr, _ = roc_curve(y_test, prob)
        roc_curves[name] = (fpr, tpr, row["ROC-AUC"])
        confusion_matrices[name] = confusion_matrix(y_test, pred)
        predictions[f"{name}_Predicted"] = pred
        predictions[f"{name}_Default_Probability"] = prob

        safe_name = name.lower().replace(" ", "_").replace("(", "").replace(")", "").replace("-", "_")
        with open(OUT / f"{safe_name}_classification_report.txt", "w", encoding="utf-8") as f:
            f.write(classification_report(y_test, pred, zero_division=0))
        print(f"\n{name}\nConfusion matrix (actual rows, predicted columns):\n{confusion_matrices[name]}")
        print(classification_report(y_test, pred, zero_division=0))

    results = pd.DataFrame(metrics).sort_values("ROC-AUC", ascending=False)
    results.to_csv(OUT / "model_comparison.csv", index=False)
    predictions.to_csv(OUT / "test_predictions.csv", index=False)
    results.to_json(OUT / "model_comparison.json", orient="records", indent=2)

    # Dataset overview
    overview = {
        "rows": int(df.shape[0]),
        "features": list(X.columns),
        "target": "Defaulted",
        "defaults": int(y.sum()),
        "non_defaults": int((y == 0).sum()),
        "default_rate_percent": round(float(y.mean() * 100), 4),
        "missing_values": int(df.isna().sum().sum()),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "random_state": RANDOM_STATE,
    }
    (OUT / "dataset_summary.json").write_text(json.dumps(overview, indent=2), encoding="utf-8")

    # Class distribution plot
    plt.figure(figsize=(6, 4))
    sns.countplot(x=y, color="steelblue")
    plt.title("Loan Default Class Distribution")
    plt.xlabel("Defaulted (0 = No, 1 = Yes)")
    plt.ylabel("Number of customers")
    plt.tight_layout()
    plt.savefig(FIG / "class_distribution.png", bbox_inches="tight")
    plt.close()

    # Correlation heatmap
    plt.figure(figsize=(7, 5))
    sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm", fmt=".2f", center=0)
    plt.title("Feature Correlation Heatmap")
    plt.tight_layout()
    plt.savefig(FIG / "correlation_heatmap.png", bbox_inches="tight")
    plt.close()

    # Model comparison
    plot_df = results.set_index("Model")[["Accuracy", "Precision", "Recall", "F1-Score", "ROC-AUC"]]
    ax = plot_df.plot(kind="bar", figsize=(10, 5))
    ax.set_title("Model Performance Comparison")
    ax.set_ylabel("Score")
    ax.set_ylim(0, 1.05)
    plt.xticks(rotation=15, ha="right")
    plt.legend(loc="lower right", fontsize=8)
    plt.tight_layout()
    plt.savefig(FIG / "model_comparison.png", bbox_inches="tight")
    plt.close()

    # ROC curves
    plt.figure(figsize=(7, 6))
    for name, (fpr, tpr, auc) in roc_curves.items():
        plt.plot(fpr, tpr, label=f"{name} (AUC={auc:.3f})")
    plt.plot([0, 1], [0, 1], "k--", linewidth=1, label="Random baseline")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curves — Four-Model Comparison")
    plt.legend(loc="lower right", fontsize=8)
    plt.tight_layout()
    plt.savefig(FIG / "roc_curves.png", bbox_inches="tight")
    plt.close()

    # Confusion matrix for the best ROC-AUC model
    best_name = results.iloc[0]["Model"]
    best_cm = confusion_matrices[best_name]
    plt.figure(figsize=(5, 4))
    sns.heatmap(best_cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["No Default", "Default"],
                yticklabels=["No Default", "Default"])
    plt.title(f"Confusion Matrix — {best_name}")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.tight_layout()
    plt.savefig(FIG / "best_model_confusion_matrix.png", bbox_inches="tight")
    plt.close()

    # Tree-based feature importance
    for model_name, model, filename in [
        ("Random Forest", models["Random Forest"], "random_forest_feature_importance.png"),
        ("XGBoost", models["XGBoost"], "xgboost_feature_importance.png"),
    ]:
        imp = pd.Series(model.feature_importances_, index=X.columns).sort_values()
        imp.rename("Importance").to_csv(OUT / f"{model_name.lower().replace(' ', '_')}_feature_importance.csv")
        plt.figure(figsize=(6, 4))
        imp.plot(kind="barh")
        plt.title(f"Feature Importance — {model_name}")
        plt.xlabel("Importance")
        plt.tight_layout()
        plt.savefig(FIG / filename, bbox_inches="tight")
        plt.close()

    # Save the selected model and its feature order for later inference.
    best_model = models[best_name]
    joblib.dump({
        "model": best_model,
        "model_name": best_name,
        "features": list(X.columns),
        "threshold": 0.5,
    }, MODEL_DIR / "best_model.joblib")

    print("\n=== Model comparison (sorted by ROC-AUC) ===")
    print(results.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    print(f"\nSelected model by ROC-AUC: {best_name}")
    print(f"Results and figures saved under: {OUT}")
    print(f"Model artifact saved to: {MODEL_DIR / 'best_model.joblib'}")

if __name__ == "__main__":
    main()
