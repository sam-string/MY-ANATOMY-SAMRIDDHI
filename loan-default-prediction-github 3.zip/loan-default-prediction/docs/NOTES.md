# Project notes

`project_report_reference.pdf` is the report supplied with the project. The repository's `src/train.py` re-runs the experiment against the supplied CSV and regenerates all evaluation outputs. Use the generated `outputs/model_comparison.csv` as the record of the actual run in your environment.
