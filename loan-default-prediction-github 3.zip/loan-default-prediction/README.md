# Loan Default Prediction System
### Comparative Study of Four Classification Algorithms

A supervised machine-learning mini project that predicts whether a customer may default on a loan using employment status, bank balance, and annual salary. It compares **Logistic Regression, Random Forest, Support Vector Machine (RBF), and XGBoost**.

> **Important:** This project is for educational purposes only. The model must not be used on its own to approve, reject, or price real loans. It uses only three features, may reflect biases in its source data, and has not been validated for real-world lending.

## Problem statement
Loan defaults are rare in this dataset, so a model can achieve high accuracy simply by predicting that almost everyone will repay. The project therefore compares accuracy alongside precision, recall, F1-score, and ROC-AUC. Recall is especially useful for understanding how many actual defaults the model catches.

## Dataset
The supplied CSV is included at `data/Default_Fin.csv`.

| Field | Meaning |
|---|---|
| `Employed` | 1 if employed, 0 otherwise |
| `Bank Balance` | Current bank balance |
| `Annual Salary` | Annual salary |
| `Defaulted?` | Target: 1 = default, 0 = no default |
| `Index` | Row identifier; removed before training |

- Records: 10,000
- Defaults: 333 (3.33%)
- Non-defaults: 9,667 (96.67%)
- Missing values: none in the supplied file
- Train/test split: 80% / 20%, stratified, random state 42

## Models and approach
1. **Logistic Regression** — balanced class weights; standardized features.
2. **Random Forest** — 300 trees; balanced class weights.
3. **SVM (RBF)** — balanced class weights; standardized features.
4. **XGBoost** — 300 estimators, depth 4, learning rate 0.05, and `scale_pos_weight` based on the training-set class ratio.

The scaler is fit only on the training split through a pipeline to avoid leakage. Tree-based models use unscaled features. All models are evaluated on the same held-out test set.

## Results
The following results were produced by running `src/train.py` on the supplied dataset (80/20 stratified split, random state 42). The complete table is saved in [`outputs/model_comparison.csv`](outputs/model_comparison.csv). The model is ranked by ROC-AUC, not accuracy alone.

| Model | Accuracy | Precision | Recall | F1-score | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Logistic Regression | 0.8550 | 0.1730 | 0.8806 | 0.2892 | 0.9487 |
| XGBoost | 0.8815 | 0.1875 | 0.7612 | 0.3009 | 0.9357 |
| SVM (RBF) | 0.8410 | 0.1617 | 0.8955 | 0.2740 | 0.9152 |
| Random Forest | 0.9695 | 0.5938 | 0.2836 | 0.3838 | 0.8893 |

| Metric | What it tells us |
|---|---|
| Accuracy | Fraction of all predictions that are correct |
| Precision | Of customers flagged as defaults, fraction that actually defaulted |
| Recall | Of actual defaults, fraction detected by the model |
| F1-score | Harmonic mean of precision and recall |
| ROC-AUC | How well the model ranks defaults above non-defaults across thresholds |

### Visual results
- Class distribution: `outputs/figures/class_distribution.png`
- Correlation heatmap: `outputs/figures/correlation_heatmap.png`
- Four-model comparison: `outputs/figures/model_comparison.png`
- ROC curves: `outputs/figures/roc_curves.png`
- Best model confusion matrix: `outputs/figures/best_model_confusion_matrix.png`
- Feature importance: `outputs/figures/random_forest_feature_importance.png` and `outputs/figures/xgboost_feature_importance.png`

### Interpretation
The report provided with the project identifies Logistic Regression as the recommended model based on ROC-AUC (0.949) and high recall (0.881), while Random Forest has high accuracy but much lower recall. This illustrates why accuracy alone can be misleading with rare defaults. Re-run `src/train.py` to reproduce the evaluation using the supplied CSV; use the generated outputs as the authoritative results for your run.

## Run locally
Use Python 3.10 or later.

```bash
# 1. Create and activate a virtual environment (optional but recommended)
python -m venv .venv

# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS/Linux
source .venv/bin/activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Train and compare all four models
python src/train.py

# 4. Predict for an example customer (run after training)
python src/predict.py --employed 1 --bank-balance 8500 --annual-salary 400000
```

Training writes comparison metrics, test predictions, classification reports, dataset summary, feature-importance tables, and charts to `outputs/`, and saves the best-by-ROC-AUC model to `models/best_model.joblib`.

## Repository structure
```text
loan-default-prediction/
├── data/
│   └── Default_Fin.csv
├── models/
│   └── best_model.joblib              # generated after training
├── outputs/
│   ├── model_comparison.csv
│   ├── model_comparison.json
│   ├── test_predictions.csv
│   ├── dataset_summary.json
│   ├── *_classification_report.txt
│   └── figures/
├── src/
│   ├── train.py
│   └── predict.py
├── requirements.txt
├── .gitignore
└── README.md
```

## Limitations and responsible use
- The dataset contains only three predictors and may omit important factors.
- The 3.33% default rate makes precision/recall trade-offs important.
- A 0.5 probability threshold is a simple default, not a bank-approved operating threshold.
- Feature importance indicates predictive association, not causation.
- Before any real deployment, assess fairness, calibration, stability, data quality, explainability, and the costs of false positives and false negatives.

## Skills demonstrated
Python, pandas, NumPy, scikit-learn, XGBoost, classification, imbalanced learning, evaluation metrics, ROC analysis, feature importance, model serialization.
